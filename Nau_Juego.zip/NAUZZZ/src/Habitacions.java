import java.util.ArrayList;
import java.util.HashMap;

public class Habitacions {

    String nom;
    int id;
    HashMap<String, Habitacions> connections;
    ArrayList<Objecte> objectes;
    Tripulant personatje;
    Gustabo gustabo;

    public Habitacions(String nom, int id) {
        this.nom = nom;
        this.id = id;
        this.connections = new HashMap<>();
        this.objectes = new ArrayList<>();
        this.personatje = null;
    }

    public void afegirObjecte(Objecte objecte) {
        this.objectes.add(objecte);
    }

    public void afegirPersonatge(Tripulant personatje) {
        this.personatje = personatje;
    }

    public void afegirGustabo(Gustabo gustabo) {
        this.gustabo = gustabo;
    }

    public void afegirDireccio(String direccio, Habitacions habitacio) {
        this.connections.put(direccio, habitacio);
    }

    public Habitacions anar(String direccio) {
        return this.connections.get(direccio);
    }

    public void mostrarObjectesITripulants() {
        if (objectes.isEmpty()) {
            System.out.println("No hi ha objectes en aquesta habitació.");
        } else {
            System.out.println("Objectes en aquesta habitació:");
            for (Objecte obj : objectes) {
                System.out.println(obj);
            }
        }
        if (personatje != null) {
            System.out.println(personatje.obtenirEstat());
        }
    }

    public Objecte interactuarPersonatge() {
        if (personatje != null) {
            return personatje.Despertarse();
        } else {
            System.out.println("No hi ha ningú aquí.");
            return null;
        }
    }

    public static void CreacioHabitacions(ArrayList<Habitacions> mapa) {
        Habitacions Dormitori = new Habitacions("Dormitori", 1);
        Habitacions Banys = new Habitacions("Banys", 2);
        Habitacions Oficines = new Habitacions("Oficines", 3);
        Habitacions Tallers = new Habitacions("Tallers", 4);
        Habitacions Vestuari = new Habitacions("Vestuari", 5);
        Habitacions Cuina = new Habitacions("Cuina", 6);
        Habitacions Menjador = new Habitacions("Menjador", 7);
        Habitacions Sala_sortida = new Habitacions("Sala Sortida Exterior", 8);
        Habitacions Comandament = new Habitacions("Comandament", 9);
        Habitacions Propulsors = new Habitacions("Propulsors", 10);

        Dormitori.afegirDireccio("W", Banys);
        Dormitori.afegirDireccio("A", Menjador);
        Banys.afegirDireccio("S", Dormitori);
        Banys.afegirDireccio("A", Oficines);
        Oficines.afegirDireccio("W", Tallers);
        Oficines.afegirDireccio("S", Comandament);
        Oficines.afegirDireccio("A", Vestuari);
        Tallers.afegirDireccio("S", Oficines);
        Tallers.afegirObjecte(new Objecte("Caixa eines", "serveix per arreglar els motors"));
        Vestuari.afegirDireccio("D", Oficines);
        Vestuari.afegirDireccio("S", Cuina);
        Vestuari.afegirObjecte(new Objecte("Vestit espacial", "Vestit per poder sortir als propulsors"));
        Cuina.afegirDireccio("W", Vestuari);
        Cuina.afegirDireccio("D", Menjador);
        Cuina.afegirObjecte(new Objecte("Donut", "Un donut que si li dones al Gustabo no es moura"));
        Menjador.afegirDireccio("S", Sala_sortida);
        Menjador.afegirDireccio("D", Dormitori);
        Menjador.afegirDireccio("A", Cuina);
        Sala_sortida.afegirDireccio("W", Menjador);
        Sala_sortida.afegirDireccio("S", Propulsors);
        Comandament.afegirDireccio("W", Oficines);
        Comandament.afegirObjecte(new Objecte("Llanterna", "Has obert el calaix i has trobat una llanterna"));
        Propulsors.afegirDireccio("W", Sala_sortida);

        Objecte Targeta = new Objecte("Targeta", "Una targeta que obre les portes. ");
        Tripulant noiDormi = new Tripulant("Noi", true, Targeta);
        Dormitori.afegirPersonatge(noiDormi);

        Gustabo gustabo = new Gustabo("Gustabo", Propulsors);
        Propulsors.afegirGustabo(gustabo);
        Propulsors.afegirGustabo(gustabo);

        mapa.add(Dormitori);
        mapa.add(Banys);
        mapa.add(Oficines);
        mapa.add(Tallers);
        mapa.add(Vestuari);
        mapa.add(Cuina);
        mapa.add(Menjador);
        mapa.add(Sala_sortida);
        mapa.add(Comandament);
        mapa.add(Propulsors);

    }

    public Objecte recollirObjecte(String nomObjecte) {
        for (Objecte obj : objectes) {
            if (obj.obtenirNom().equalsIgnoreCase(nomObjecte)) {
                objectes.remove(obj);
                return obj;
            }
        }
        System.out.println("No hi ha cap objecte amb aquest nom.");
        return null;
    }

    public String obtenirNom() {
        return this.nom;
    }
}