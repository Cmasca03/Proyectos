import java.util.HashMap;

public class Gustabo {
    private String nom;
    private Habitacions posicioActual;
    private boolean haMenjatDonut = false;

    public Gustabo(String nom, Habitacions posicioInicial) {
        this.nom = nom;
        this.posicioActual = posicioInicial;
    }

    public void usarDonut() {
        System.out.println("Gustabo ha comido el Donut.");
        haMenjatDonut = true;
    }

    public boolean comerDonut() {
        return haMenjatDonut;
    }

    public Habitacions anar3(String direccio, HashMap<String, Habitacions> connections) {
        if (haMenjatDonut) {
            System.out.println(nom + " està massa ple per moure's després de menjar-se el Donut.");
            return null;
        }
        return connections.get(direccio);
    }

    public String obtenirNom() {
        return nom;
    }

    public Habitacions obtenirPosicioActual() {
        return posicioActual;
    }

}
