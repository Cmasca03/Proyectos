import java.util.HashMap;

public class Tripulant {
    String nom;
    boolean dormint = true;
    Objecte Tarjeta;

    public Tripulant(String nom, boolean dormint, Objecte Tarjeta) {
        this.nom = nom;
        this.dormint = dormint;
        this.Tarjeta = Tarjeta;
    }

    public String obtenirNom() {
        return this.nom;
    }

    public boolean estaDormint() {
        return this.dormint;
    }

    public Habitacions anar2(String direccio, HashMap<String, Habitacions> connections) {
        return connections.get(direccio);
    }

    public Objecte Despertarse() {
        if (this.dormint) {
            this.dormint = false;
            System.out.println(nom + " s'ha despertat!");
            return Tarjeta;
        } else {
            System.out.println(nom + " ja està despert.");
            return null;
        }
    }

    public String obtenirEstat() {
        if (this.dormint) {
            return nom + " està dormint.";
        } else {
            return nom + " està despert.";
        }
    }
}

