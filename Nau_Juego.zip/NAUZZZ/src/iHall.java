import java.util.Random;


public class iHall {

    static Random rand = new Random();

    public static void Ajuda(Habitacions posicioActual) {
        
        int opcions = rand.nextInt(0,1);

        switch (opcions) {
            case 0:
                if (posicioActual.obtenirNom().equals("Dormitori")) {
                    System.out.println("Desperta el noi y potser et dona la targeta.");
                }
                
                if (posicioActual.obtenirNom().equals("Banys")) {
                    System.out.println("Si et mous a la teva esquerra?");
                }

                if (posicioActual.obtenirNom().equals("Oficines")) {
                    System.out.println("Si vas cap a dalt trobaras els Tallers i potser hi ha algo. Si vas cap abaix trobaras la Sala de Comanadament.");
                }

                if (posicioActual.obtenirNom().equals("Tallers")) {
                    System.out.println("La caixa d'eines et sera util per repara els motors.");
                }

                if (posicioActual.obtenirNom().equals("Vestuari")) {
                    System.out.println("El Vestit espacial et sera util per sortir fora.");
                }

                if (posicioActual.obtenirNom().equals("Cuina")) {
                    System.out.println("El Donut et sera util si et trobes en Gustabo...");
                }

                if (posicioActual.obtenirNom().equals("Menjador")) {
                    System.out.println("Quina fred que fa es com si tinguessim la sortida darrera nostre.");
                }

                if (posicioActual.obtenirNom().equals("Sala Sortida Exterior")) {
                    System.out.println("Revisa que ho tinguis tot per poder sortir i tornar amb tot arreglat.");
                }

                if (posicioActual.obtenirNom().equals("Comandament")) {
                    System.out.println("Nomes podem tornar per on hem entrat.");
                }
                
                if (posicioActual.obtenirNom().equals("Propulsors")) {
                    System.out.println("Saps fer servir la caixa d'eienes?");
                }

                break;
            case 1:
                if (posicioActual.obtenirNom().equals("Dormitori")) {
                    System.out.println("Tenia gana i me l'he esmorzat.");
                }
                                
                if (posicioActual.obtenirNom().equals("Banys")) {
                    System.out.println("S'ha caigut al lavabo quantic.");
                }

                if (posicioActual.obtenirNom().equals("Oficines")) {
                    System.out.println("Tinc 0 hores cotitzades...");
                }

                if (posicioActual.obtenirNom().equals("Tallers")) {
                    System.out.println("Ens la vam deixar a la Terra.");
                }

                if (posicioActual.obtenirNom().equals("Vestuari")) {
                    System.out.println("A que vaig jo i la trobo...");
                }

                if (posicioActual.obtenirNom().equals("Cuina")) {
                    System.out.println("Has mirat a sota la bandeja.");
                }

                if (posicioActual.obtenirNom().equals("Menjador")) {
                    System.out.println("Tens menjar per sentar-te a menjar?");
                }

                if (posicioActual.obtenirNom().equals("Sala Sortida Exterior")) {
                    System.out.println("Potser t'has deixat el Vestit Espacial");
                }

                if (posicioActual.obtenirNom().equals("Comandament")) {
                    System.out.println("A mi que em preguntes.");
                }
                
                if (posicioActual.obtenirNom().equals("Propulsors")) {
                    System.out.println("Tu sabràs on deixes les teves coses capsigrany.");
                }
                break;
            default:
                break;
        }
    }
}
