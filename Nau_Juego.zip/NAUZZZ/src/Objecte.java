public class Objecte {
    private String nom;
    private String descripcio;

    public Objecte(String nom, String descripcio) {
        this.nom = nom;
        this.descripcio = descripcio;
    }

    public String obtenirNom() {
        return this.nom;
    }

    public String obtenirDescripcio() {
        return this.descripcio;
    }

    public void usar(Gustabo gustabo) {
        if (nom.equalsIgnoreCase("Donut")) {
            System.out.println("Has llançat el Donut a Gustabo!");
            if (gustabo != null) {
                gustabo.usarDonut(); // Gustabo se come el Donut
            }
        } else if (nom.equalsIgnoreCase("Llanterna")) {
            System.out.println("Has encès la llanterna, ara veus tot més clar.");
        } else if (nom.trim().equalsIgnoreCase("Caixa Eines")) {
            System.out.println("Has utilitzat la Caixa d'Eines per arreglar el motor de la nau.");
        } else {
            System.out.println("Has utilitzat l'objecte: " + nom);
        }
    }

    @Override
    public String toString() {
        return nom + ": " + descripcio;
    }
}
