import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Nau {
    Scanner e = new Scanner(System.in);
    ArrayList<Habitacions> mapa = new ArrayList<>(9);
    ArrayList<Objecte> inventari = new ArrayList<>();
    String resposta;
    int torn;
    Random rand = new Random();
    boolean vestitPosat = false; // Variable para controlar si el personaje lleva el "Vestit espacial"
    Habitacions posicioActual;
    boolean victoria = false;
    public static void main(String[] args) throws Exception {
        Nau nau = new Nau();
        nau.principal();
    }

    public void principal() {

        System.out.println("Benvigut a una historia interactiva.");
        Habitacions.CreacioHabitacions(mapa);

        Habitacions posicioActual = mapa.get(0);
        Tripulant noiDormi = posicioActual.personatje;
        Habitacions PosicioActualG = mapa.get(9);
        Gustabo gustabo = PosicioActualG.gustabo;

        while (!victoria) {
            System.out.println("Ets a " + posicioActual.obtenirNom());
            posicioActual.mostrarObjectesITripulants();

            System.out.println(
                    "Escriu INTERACTUAR per interactuar, RECOLLIR [NOM OBJECTE] per recollir un objecte, UTILITZAR [NOM OBJECTE], POSAR [NOM OBJECTE], Ayuda [iHall], o W A S D per moure't.");
            resposta = e.nextLine().toUpperCase();

            if (resposta.startsWith("RECOLLIR ")) {
                String itemName = resposta.substring(9);
                Objecte item = posicioActual.recollirObjecte(itemName);
                if (item != null) {
                    inventari.add(item);
                    System.out.println("Has recollit l'objecte: " + item.obtenirNom());
                }
                continue;
            }

            if (resposta.startsWith("UTILITZAR ")) {
                String itemName = resposta.substring(9);
                usarObjecte(itemName, gustabo);
                if (itemName.trim().equalsIgnoreCase("CAIXA EINES") && posicioActual.obtenirNom().equalsIgnoreCase("Propulsors")) {
                    victoria=true;
                }
                continue;
            }

            if (resposta.equals("AJUDA")) {
                iHall.Ajuda(posicioActual);
                continue;
            }

            if (resposta.startsWith("POSAR ")) {
                String itemName = resposta.substring(5);
                posarObjecte(itemName);
                continue;
            }

            if (resposta.equals("INTERACTUAR")) {
                Objecte item = posicioActual.interactuarPersonatge();
                if (item != null) {
                    System.out.println("Has rebut un objecte: " + item.obtenirNom() + " - " + item.obtenirDescripcio());
                    inventari.add(item);
                } else {
                    System.out.println("No hi ha res per interactuar.");
                }
                continue;
            }

            
            System.err.println(" ");
            Habitacions Novaposicio = posicioActual.anar(resposta);

            if (Novaposicio != null) {
                if (Novaposicio.obtenirNom().equalsIgnoreCase("Propulsors") && !vestitPosat) {
                    System.out.println("No pots entrar als Propulsors sense posar-te el Vestit espacial.");
                } else {
                    posicioActual = Novaposicio;
                    System.out.println("T'has mogut a l'habitació: " + posicioActual.obtenirNom());
                }
            } else {
                System.out.println("No pots moure't en aquesta direcció.");
            }

            torn++;

            if (!noiDormi.estaDormint()) {
                String[] direccions = { "W", "A", "S", "D" };
                String direccioAleatoria = direccions[rand.nextInt(direccions.length)];
                Habitacions novaHabitacio = noiDormi.anar2(direccioAleatoria, posicioActual.connections);
                if (novaHabitacio != null) {
                    System.out.println(
                            noiDormi.obtenirNom() + " s'ha mogut a l'habitació: " + novaHabitacio.obtenirNom());
                } else {
                    System.out.println(noiDormi.obtenirNom() + " no pot moure's en aquesta direcció.");
                }
            }

            if (torn % 2 == 0) {
                String[] direccions = { "W", "A", "S", "D" };
                String direccioAleatoria = direccions[rand.nextInt(direccions.length)];
                Habitacions novaHabitacio = gustabo.anar3(direccioAleatoria, posicioActual.connections);
                if (novaHabitacio != null) {
                    System.out.println(
                            "Gustabo s'ha mogut a l'habitació: " + novaHabitacio.obtenirNom());
                } else {
                    System.out.println("Gustabo no pot moure's en aquesta direcció.");
                }
            }
        }
    }

    public void mostrarInventari() {
        if (inventari.isEmpty()) {
            System.out.println("El teu inventari és buit.");
        } else {
            System.out.println("Inventari:");
            for (Objecte obj : inventari) {
                System.out.println(obj.obtenirNom() + ": " + obj.obtenirDescripcio());
            }
        }
    }

    // Método para ponerse el Vestit espacial
    private void posarObjecte(String nomObjecte) {
        boolean objecteTrobat = false;

        for (Objecte obj : inventari) {
            if (obj.obtenirNom().equalsIgnoreCase(nomObjecte.trim())) {
                objecteTrobat = true;

               

                if (nomObjecte.trim().equalsIgnoreCase("Vestit espacial")) {
                    vestitPosat = true; // Indicar que el vestit está puesto
                    System.out.println("T'has posat el Vestit espacial! Ara pots entrar als Propulsors.");
                }
            }
        }

        if (!objecteTrobat) {
            System.out.println("No tens l'objecte: " + nomObjecte);
        }
    }

    // Método para usar objetos (no cambia)
    private void usarObjecte(String nomObjecte, Gustabo gustabo) {
        boolean objecteTrobat = false;

        for (Objecte obj : inventari) {
            if (obj.obtenirNom().equalsIgnoreCase(nomObjecte.trim())) {
                objecteTrobat = true;
                obj.usar(gustabo);
                if (nomObjecte.equalsIgnoreCase("Caixa eines")
                && posicioActual.obtenirNom().equalsIgnoreCase("Propulsors")) {
                    System.out.println("Has utilitzat la Caixa d'Eines per arreglar els propulsors.");
                    victoria=true;
                }
                if (nomObjecte.equalsIgnoreCase("Donut") && gustabo.comerDonut()) {
                    inventari.remove(obj);
                    System.out.println(
                            "Has usat el Donut i Gustabo se l'ha menjat. El Donut ha estat eliminat del teu inventari.");
                }
                return;
            }
        }

        if (!objecteTrobat) {
            System.out.println("No tens l'objecte: " + nomObjecte);
        }
    }
}

